# Databricks notebook source
raw_folder_path = '/mnt/formula1dl59/raw'
processed_folder_path = "/mnt/formula1dl59/processed"
presentation_folder_path = '/mnt/formula1dl59/presentation'

# COMMAND ----------

#raw_folder_path = 'abfs://raw@formula1dl59.dfs.core.windows.net'
#processed_folder_path = 'abfs://processed@formula1dl59.dfs.core.windows.net'
#presentation_folder_path = 'abfs://presentation@formula1dl59.dfs.core.windows.net'

# COMMAND ----------

