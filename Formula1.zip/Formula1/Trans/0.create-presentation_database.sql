-- Databricks notebook source
create database if not exists f1_presentation
location "/mnt/formula1dl59/presentation"

-- COMMAND ----------

du